"""用小型人工資料驗證核心邏輯。執行：pytest -q"""
import numpy as np
import pandas as pd

from scm_risk import pipeline as p


def make_df(days=20):
    rows = []
    for sku, cost in (("SKU_1", 10.0), ("SKU_2", 1.0)):
        for wh in ("WH_1", "WH_2"):
            for i, d in enumerate(pd.date_range("2024-01-01", periods=days)):
                rows.append(dict(
                    date=d, sku_id=sku, warehouse_id=wh, supplier_id="SUP_1", region="N",
                    units_sold=10, inventory_level=100 - i, supplier_lead_time_days=5,
                    reorder_point=50, order_quantity=0, unit_cost=cost, unit_price=cost * 1.5,
                    promotion_flag=0, stockout_flag=0, demand_forecast=10.0))
    return pd.DataFrame(rows)


def prepared():
    return p.engineer_features(p.standardize(make_df()))


def test_rolling_window_first_six_are_nan():
    df = prepared()
    g = df[(df.sku == "SKU_1") & (df.warehouse == "WH_1")].sort_values("date")
    assert g["days_of_supply"].iloc[:6].isna().all()
    assert g["days_of_supply"].iloc[6:].notna().all()


def test_days_of_supply_value():
    df = prepared()
    row = df[(df.sku == "SKU_1") & (df.warehouse == "WH_1")].sort_values("date").iloc[6]
    assert np.isclose(row["days_of_supply"], row["inventory"] / 10)


def test_duplicate_key_raises():
    raw = pd.concat([make_df(), make_df().iloc[:1]])
    try:
        p.standardize(raw)
    except ValueError:
        return
    raise AssertionError("expected ValueError")


def test_missing_column_raises():
    try:
        p.standardize(make_df().drop(columns=["units_sold"]))
    except KeyError:
        return
    raise AssertionError("expected KeyError")


def test_abc_classes_cover_all_and_sum_to_100():
    df = prepared()
    sku_abc, summary = p.abc_analysis(df)
    assert sku_abc["abc_class"].isin(["A", "B", "C"]).all()
    assert np.isclose(summary["value_share_pct"].sum(), 100)
    assert sku_abc.loc[0, "sku"] == "SKU_1"  # 成本較高者排第一


def test_risk_level_low_exists_when_metric_zero():
    df = prepared()
    sku_abc, _ = p.abc_analysis(df)
    risk, th = p.risk_analysis(df, sku_abc)
    zero = risk[p.RISK_METRIC] == 0
    assert (risk.loc[zero, "risk_level"] == "Low").all()
    assert (risk.loc[~zero, "risk_level"] != "Low").all()


def test_scenario_monotonic():
    df = prepared()
    _, summ = p.scenario_analysis(df)
    base = summ[(summ.demand_growth == 0) & (summ.lead_time_growth == 0)]["avg_shortfall_rate"].iloc[0]
    worst = summ[(summ.demand_growth == 0.2) & (summ.lead_time_growth == 0.2)]["avg_shortfall_rate"].iloc[0]
    assert worst >= base
