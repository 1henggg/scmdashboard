"""產生與 Kaggle 資料集欄位相同的『模擬』資料，僅供沒有原始 CSV 時測試流程。

⚠️ 這不是真實資料，不要把用它算出的結果寫進履歷或 README。
用法：python scripts/make_sample_data.py --out data/raw/sample_supply_chain.csv
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def make(n_sku=50, n_wh=5, n_sup=10, days=365, seed=42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2024-01-01", periods=days)
    regions = np.array(["North", "South", "East", "West"])
    rows = []
    for s in range(1, n_sku + 1):
        cost = rng.uniform(8, 20)
        price = cost * rng.uniform(1.2, 1.5)
        sup = f"SUP_{rng.integers(1, n_sup + 1)}"
        for w in range(1, n_wh + 1):
            lead = int(rng.integers(5, 15))
            base = rng.uniform(15, 25)
            rop = int(base * lead * 1.3)
            inv = int(rng.integers(450, 650))
            for d in dates:
                demand = max(0, int(rng.normal(base, 6)))
                order = 0
                if inv < rop:
                    order = int(base * 25)
                inv = max(0, inv - demand + (order if rng.random() < 0.05 else 0))
                rows.append((d, f"SKU_{s}", f"WH_{w}", sup, rng.choice(regions), demand, inv,
                             lead, rop, order, round(cost, 2), round(price, 2),
                             int(rng.random() < 0.1), 0, round(max(0.0, demand + rng.normal(0, 2.5)), 2)))
    return pd.DataFrame(rows, columns=[
        "date", "sku_id", "warehouse_id", "supplier_id", "region", "units_sold",
        "inventory_level", "supplier_lead_time_days", "reorder_point", "order_quantity",
        "unit_cost", "unit_price", "promotion_flag", "stockout_flag", "demand_forecast",
    ])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/raw/sample_supply_chain.csv", type=Path)
    a = ap.parse_args()
    a.out.parent.mkdir(parents=True, exist_ok=True)
    make().to_csv(a.out, index=False)
    print("wrote", a.out)
