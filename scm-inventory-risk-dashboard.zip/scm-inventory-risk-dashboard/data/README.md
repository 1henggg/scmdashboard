# 資料

本 repo **不包含原始資料**。請自行從 Kaggle 下載後放到：

```
data/raw/supply_chain_dataset1.csv
```

> TODO：把下方換成你實際使用的 Kaggle 資料集名稱與連結，並確認該資料集的授權條款。
> Dataset: `<名稱>` — https://www.kaggle.com/datasets/<owner>/<dataset>

## 預期欄位（15 欄）

`date, sku_id, warehouse_id, supplier_id, region, units_sold, inventory_level,
supplier_lead_time_days, reorder_point, order_quantity, unit_cost, unit_price,
promotion_flag, stockout_flag, demand_forecast`

粒度：一列 = 一個日期 × SKU × 倉庫（不可重複）。

## 沒有 CSV 時

`python scripts/make_sample_data.py` 會產生欄位相同的**模擬資料**，只用來測試流程能否跑通。
用它算出的數字沒有任何意義，不要放進履歷或 README 的結果。
